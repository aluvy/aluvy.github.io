		<div id="sub_title">
 			<img src="../img/title_left_menu.gif">
		</div>
		<ul>
		<li>낙서장</li>
		<li>가입인사</li>
		<li>연주회소개</li>
		<li>자료실</li>
		<li>자유게시판</li>
		<li>레슨문의</li>
		<li>설문조사</li>
		</ul>