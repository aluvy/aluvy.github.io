﻿<meta charset="utf-8">
<?
    @extract($_GET); 
    @extract($_POST); 
    @extract($_SESSION); 

    /*
    $id="green"; (get)
    */

    if(!$id)    // id가 입력되지 않았다면
    {
        echo("아이디를 입력하세요.");
    }
    else
    {
        include "../lib/dbconn.php";

        $sql = "select * from member where id='$id' ";

        $result = mysql_query($sql, $connect);
        $num_record = mysql_num_rows($result);


        // if ($num_record)    // 검색 레코드가 있으면
        // {
        //     echo "<div><img src='../img/id_no.jpg' alt=' ' /></div>";

        // }
        // else
        // {
        //     echo "<div><img src='../img/id_ok.jpg' alt=' ' /></div>";
        // }

        if ($num_record)
        {
            echo "아이디가 중복됩니다!<br>";
            echo "다른 아이디를 사용하세요.<br>";
        }
        else
        {
            echo "사용가능한 아이디입니다.";
        }
        
        mysql_close();
    }
?>

