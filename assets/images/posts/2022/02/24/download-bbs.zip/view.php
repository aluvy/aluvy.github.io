<? 
	session_start(); 
    @extract($_POST);
    @extract($_GET);
    @extract($_SESSION);

	include "../lib/dbconn.php";

	$sql = "select * from $table where num=$num";
	$result = mysql_query($sql, $connect);

    $row = mysql_fetch_array($result);       

	$item_num     = $row[num];
	$item_id      = $row[id];
	$item_name    = $row[name];
  	$item_nick    = $row[nick];
	$item_hit     = $row[hit];

	$file_name[0]   = $row[file_name_0];
	$file_name[1]   = $row[file_name_1];
	$file_name[2]   = $row[file_name_2];

	$file_type[0]   = $row[file_type_0];
	$file_type[1]   = $row[file_type_1];
	$file_type[2]   = $row[file_type_2];

	$file_copied[0] = $row[file_copied_0];
	$file_copied[1] = $row[file_copied_1];
	$file_copied[2] = $row[file_copied_2];

    $item_date    = $row[regist_day];
	$item_subject = str_replace(" ", "&nbsp;", $row[subject]);

	$item_content = str_replace(" ", "&nbsp;", $row[content]);
	$item_content = str_replace("\n", "<br>", $item_content);
	$new_hit = $item_hit + 1;

	$sql = "update $table set hit=$new_hit where num=$num";   // 글 조회수 증가시킴
	mysql_query($sql, $connect);
?>
<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>다운로드</title>
	<link href="../css/common.css" rel="stylesheet" type="text/css" media="all">
	<link href="../css/board3.css" rel="stylesheet" type="text/css" media="all">
	<script>
		function del(href) 
		{
			if(confirm("한번 삭제한 자료는 복구할 방법이 없습니다.\n\n정말 삭제하시겠습니까?")) {
				document.location.href = href;
			}
		}
	</script>
</head>

<body>
	<div id="wrap">

		<div id="header"><? include "../lib/top_login2.php"; ?></div>
		<div id="menu"><? include "../lib/top_menu2.php"; ?></div>

		<div id="content">
			<div id="col1">
				<div id="left_menu"><? include "../lib/left_menu.php"; ?></div>
			</div>

			<div id="col2">     
				<div id="title"><img src="../img/title_download.gif"></div>
				<div id="view_comment"></div>

				<div id="view_title">
					<div id="view_title1"><?= $item_subject ?></div>
					<div id="view_title2"><?= $item_nick ?> | 조회 : <?= $item_hit ?> | <?= $item_date ?></div>	
				</div>

				<div id="view_content">
					<?
						for ($i=0; $i<3; $i++)
						{
							if ($userid && $file_copied[$i])	// 로그인, 첨부된 파일이 있으면
							{
								$show_name = $file_name[$i];
								$real_name = $file_copied[$i];
								$real_type = $file_type[$i];
								$file_path = "./data/".$real_name;	//	경로 ./data/2022_02_24_10_29_32_0.zip
								$file_size = filesize($file_path);	// 파일의 용량

								echo "▷ 첨부파일 : $show_name ($file_size Byte) &nbsp;&nbsp;&nbsp;&nbsp;
									<a href='download.php?table=$table&num=$num&real_name=$real_name&show_name=$show_name&file_type=$real_type'>[저장]</a><br>";
							}
						}
					?>
		    		<br>
					<?= $item_content ?>
				</div>

				<div id="view_button">
					<a href="list.php?table=<?=$table?>&page=<?=$page?>"><img src="../img/list.png"></a>&nbsp;
					
					<? if($userid && ( $userid==$item_id || $userid=='admin' || $userlevel==1) ){ ?>
					<a href="write_form.php?table=<?=$table?>&mode=modify&num=<?=$num?>&page=<?=$page?>"><img src="../img/modify.png"></a>&nbsp;
					<a href="javascript:del('delete.php?table=<?=$table?>&num=<?=$num?>')"><img src="../img/delete.png"></a>&nbsp;
					<? } ?>

					<? if($userid) { ?>
					<a href="write_form.php?table=<?=$table?>"><img src="../img/write.png"></a>
					<? } ?>

				</div>
				<div class="clear"></div>

			</div> <!-- end of col2 -->
  		</div> <!-- end of content -->
	</div> <!-- end of wrap -->

</body>
</html>
