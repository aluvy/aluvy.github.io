<? 
	session_start(); 
	@extract($_POST);
	@extract($_GET);
	@extract($_SESSION);
?>
<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>가입인사 게시판</title>
	<link href="../css/common.css" rel="stylesheet" media="all">
	<link href="../css/greet.css" rel="stylesheet" media="all">
</head>
<?
	include "../lib/dbconn.php";

	
	if (!$scale){
		$scale = 10;	// 한 화면에 표시되는 글 수
	}

	if ($mode=="search")	// 검색 버튼을 통한 리스트 출력
	{
		if(!$search)	// input입력값 없이 검색버튼 클릭 시
		{
			echo("
				<script>
				window.alert('검색할 단어를 입력해 주세요!');
				history.go(-1);
				</script>
			");
			exit;
		}

		$sql = "select * from greet where $find like '%$search%' order by num desc";	// 검색내용 표시
	}
	else	// 일반 리스트 출력(페이지번호)
	{
		$sql = "select * from greet order by num desc";
	}


	$result = mysql_query($sql, $connect);
	$total_record = mysql_num_rows($result); // 전체 글 수

	// 전체 페이지 수($total_page) 계산 
	if ($total_record % $scale == 0)
	{
		$total_page = floor($total_record/$scale);
	}
	else
	{
		$total_page = floor($total_record/$scale) + 1;
	}
	
	if (!$page){                 // 페이지번호($page)가 0 일 때
		$page = 1;	// 페이지 번호를 1로 초기화
	}
 
	// 표시할 페이지($page)에 따라 $start 계산
	$start = ($page - 1) * $scale;
	$number = $total_record - $start;
?>
<body>
	<div id="wrap">
		<div id="header"><? include "../lib/top_login2.php"; ?></div>
		<div id="menu"><? include "../lib/top_menu2.php"; ?></div>

		<div id="content">
			<div id="col1">
				<div id="left_menu"><? include "../lib/left_menu.php"; ?></div>
			</div>
			<div id="col2">

				<div id="title"><img src="../img/title_greet.gif"></div>

				<form  name="board_form" method="post" action="list.php?mode=search"> 
					<div id="list_search">
						<div id="list_search1">▷ 총 <?= $total_record ?> 개의 게시물이 있습니다.</div>
						<div id="list_search2"><img src="../img/select_search.gif"></div>
						<div id="list_search3">
							<select name="find">
								<option value='subject'>제목</option>
								<option value='content'>내용</option>
								<option value='nick'>별명</option>
								<option value='name'>이름</option>
							</select>
						</div>
						<div id="list_search4"><input type="text" name="search"></div>
						<div id="list_search5"><input type="image" src="../img/list_search_button.gif"></div>
					</div>
				</form>

				<select name="scale" onchange="location.href='list.php?scale='+this.value">
					<option value=''>보기</option>
					<option value='1'>1</option>
					<option value='2'>2</option>
					<option value='3'>3</option>
					<option value='4'>4</option>
				</select>

				<div class="clear"></div>

				<div id="list_top_title">
					<ul>
						<li id="list_title1"><img src="../img/list_title1.gif"></li>
						<li id="list_title2"><img src="../img/list_title2.gif"></li>
						<li id="list_title3"><img src="../img/list_title3.gif"></li>
						<li id="list_title4"><img src="../img/list_title4.gif"></li>
						<li id="list_title5"><img src="../img/list_title5.gif"></li>
					</ul>
				</div>

				<div id="list_content">
					<?		
						for ($i=$start; $i<$start+$scale && $i < $total_record; $i++)
						{
							mysql_data_seek($result, $i);
							// 가져올 레코드로 위치(포인터) 이동
							$row = mysql_fetch_array($result);
							// 하나의 레코드 가져오기

							$item_num     = $row[num];	// 실제 해당 레코드의 num필드에 있는 게시번호, 프라이머리 키
							$item_id      = $row[id];
							$item_name    = $row[name];
							$item_nick    = $row[nick];
							$item_hit     = $row[hit];

							$item_date    = $row[regist_day];	// 2022-02-21 (11:10)
							$item_date = substr($item_date, 0, 10);	// 2022-02-21

							$item_subject = str_replace(" ", "&nbsp;", $row[subject]);
							// srt_replace 문자를 교체함. " "공백문자가 들어있으면 &nbsp; 로 변경해서 찍는다.

					?>
					<div id="list_item">
						<div id="list_item1"><?= $number ?></div>
						<div id="list_item2">
							<a href="view.php?num=<?=$item_num?>&page=<?=$page?>"><?= $item_subject ?></a>
						</div>
						<div id="list_item3"><?= $item_nick ?></div>
						<div id="list_item4"><?= $item_date ?></div>
						<div id="list_item5"><?= $item_hit ?></div>
					</div>
					<?
							$number--;
						}
					?>
					<div id="page_button">
						<div id="page_num">
							◀ 이전 &nbsp;&nbsp;&nbsp;&nbsp; 
							<?
								// 게시판 목록 하단에 페이지 링크 번호 출력
								for ($i=1; $i<=$total_page; $i++)
								{
									if ($page == $i)     // 현재 페이지 번호 링크 안함
									{
										echo "<b> $i </b>";
									}
									else
									{
										if($mode=="search")	// 검색리스트일 때 (page, scale, mode, find, search)
										{
											echo "<a href='list.php?page=$i&scale=$scale&mode=search&find=$find&search=$search'> $i </a>";
										}
										else
										{    // 일반 리스트일 때
											echo "<a href='list.php?page=$i&scale=$scale'> $i </a>";
										}
									}
								}
							?>
							&nbsp;&nbsp;&nbsp;&nbsp;다음 ▶
						</div>
						<div id="button">
							<a href="list.php?page=<?=$page?>"><img src="../img/list.png"></a>&nbsp;
							<? if($userid){	// 로그인 했을 경우 ?>
								<a href="write_form.php"><img src="../img/write.png"></a>
							<? } ?>
						</div>
					</div><!-- end of page_button -->

				</div><!-- end of list content -->

				<div class="clear"></div>

			</div><!-- end of col2 -->
		</div><!-- end of content -->
	</div><!-- end of wrap -->

</body>
</html>
