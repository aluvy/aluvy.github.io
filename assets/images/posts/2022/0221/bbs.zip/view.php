<? 
	session_start(); 
	@extract($_POST);
	@extract($_GET);
	@extract($_SESSION);

    //세션변수
    //view.php?num=7&page=1

	include "../lib/dbconn.php";

	$sql = "select * from greet where num=$num";
	$result = mysql_query($sql, $connect);

    $row = mysql_fetch_array($result);       
      // 하나의 레코드 가져오기
	
	$item_num     = $row[num];
	$item_id      = $row[id];
	$item_name    = $row[name];
  	$item_nick    = $row[nick];
	$item_hit     = $row[hit];

    $item_date    = $row[regist_day];

	$item_subject = str_replace(" ", "&nbsp;", $row[subject]); 	// 공백문자 대체

	$item_content = $row[content];
	$is_html      = $row[is_html];

	if ($is_html!="y")
	{
		$item_content = str_replace(" ", "&nbsp;", $item_content);	// 공백문자 대체
		$item_content = str_replace("\n", "<br>", $item_content);	// 내려쓰기 대체
	}

	$new_hit = $item_hit + 1;

	$sql = "update greet set hit=$new_hit where num=$num";   // 글 조회수 증가시킴
	mysql_query($sql, $connect);
?>
<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link href="../css/common.css" rel="stylesheet" media="all">
	<link href="../css/greet.css" rel="stylesheet" media="all">
	<script>
		function del(href) 
		{
			if(confirm("한번 삭제한 자료는 복구할 방법이 없습니다.\n\n정말 삭제하시겠습니까?")) {
					document.location.href = href;
			}
		}
	</script>
</head>

<body>
	<div id="wrap">
		<div id="header"><? include "../lib/top_login2.php"; ?></div>
		<div id="menu"><? include "../lib/top_menu2.php"; ?></div>
  
		<div id="content">
			<div id="col1">
				<div id="left_menu"><? include "../lib/left_menu.php"; ?></div>
			</div>

			<div id="col2">
				
				<div id="title"><img src="../img/title_greet.gif"></div>

				<div id="view_comment"> &nbsp;</div>

				<div id="view_title">
					<div id="view_title1"><?= $item_subject ?></div>
					<div id="view_title2"><?= $item_nick ?> | 조회 : <?= $item_hit ?> | <?= $item_date ?> </div>	
				</div>

				<div id="view_content"><?= $item_content ?></div>

				<div id="view_button">
					<a href="list.php?page=<?=$page?>"><img src="../img/list.png"></a>
					<? 
						if($userid==$item_id || $userlevel==1 || $userid=="admin")
						// 로그인된 아이디 == 글쓴이 이거나 최고 관리자면 참
						{
					?>
					<a href="modify_form.php?num=<?=$num?>&page=<?=$page?>"><img src="../img/modify.png"></a>
					<a href="javascript:del('delete.php?num=<?=$num?>')"><img src="../img/delete.png"></a>
					<?
						}
					?>
					<? 
						if($userid)  //로그인이 되면 글쓰기
						{
					?>
					<a href="write_form.php"><img src="../img/write.png"></a>
					<?
						}
					?>
				</div>

				<div class="clear"></div>

			</div><!-- end of col2 -->
		</div><!-- end of content -->
	</div><!-- end of wrap -->

</body>
</html>