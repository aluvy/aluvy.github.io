// gsap.to()
// 애니메이션 끝 값 설정
gsap.to(".gsap_to .box1", { duration:3, x:100, opacity:0.2, ease: 'step(10)', delay:2 });
gsap.to(".gsap_to .box2", { duration:3, x:200, rotate: 720, scale: 1.3, });
gsap.to(".gsap_to .box3", { duration:10, x:200, ease: 'elastic', backgroundColor: 'red', width: 300, fontSize: 25, });



// gsap.from(), gsap.fromTo(), gsap.set()
// 애니메이션 시작값, 끝값, 초기셋팅값 걸정
gsap.from(".gsap_fromTo .box1", { duration: 3, x: 200, width: 500, opacity: 0.2, ease: 'steps(20)'});	// 시작값으로 설정된다
gsap.fromTo(".gsap_fromTo .box2", { width: 10 }, { duration: 3, x: 300, width:500, fontSize: 16 });		// 시작값과 종료값을 설정한다.
gsap.set(".gsap_fromTo .box3", { x: 500, width: 200, backgroundColor: 'skyblue', });						// set()은 애니메이션 효과 없이 즉시 변경된다.



// gsap.play(), gsap.pause(), gsap.resume(), gsap.reverse(), gsap.restart()
// 애니메이션을 멈추거나 재실행하는 등의 핸들링도 가능하다.
let playBtn = gsap.to(".gsap_play .box", { duration: 50, x:500, fontSize:20, ease:'elastic' });
document.getElementById("play").addEventListener("click", function(){
	playBtn.play();
})
document.getElementById("pause").addEventListener("click", function(){
	playBtn.pause();
})
document.getElementById("resume").addEventListener("click", function(){
	playBtn.play();
})
document.getElementById("resume").addEventListener("click", function(){
	playBtn.play();
})
document.getElementById("reverse").addEventListener("click", function(){
	playBtn.reverse();
})
document.getElementById("restart").addEventListener("click", function(){
	playBtn.restart();
})



// timeline
// delay를 이용해 애니메이션을 순차적으로 실행할 수 있다.
gsap.to(".gsap_delay .box", { duration: 3, x:200, fontSize:20, ease:'elastic' });
gsap.to(".gsap_delay .box", { duration: 3, y:200, fontSize:20, color:'#fff', delay:3 });
gsap.to(".gsap_delay .box", { duration: 3, x:0, delay:6 });
gsap.to(".gsap_delay .box", { duration: 3, y:0, delay:9 });



// scroll trigger plug-in
gsap.registerPlugin({ScrollTrigger});



// ScrollTrigger
gsap.to(".ScrollTrigger_box", { scrollTrigger : ".ScrollTrigger_box", x: 400, duration: 5, });

gsap.to(".toggleAction_box", { scrollTrigger : {
	trigger: ".toggleAction_box",
	toggleActions: "restart none reverse none",
	// onEnter : ONENTER,
}, x: 400, duration: 2,})

ScrollTrigger.create({
	trigger : ".toggleAction_box",
	onEnter: ONENTER,
	onLeave: ONLEAVE,
	onEnterBack: ONENTERBACK,
	onLeaveBack: ONLEAVEBACK
});

// let BODY = document.querySelector('body');
function ONENTER(){
	document.querySelector(".ScrollTrigger_fix").innerHTML = 'ScrollTrigger : onEnter';
}
function ONLEAVE(){
	document.querySelector(".ScrollTrigger_fix").innerHTML = 'ScrollTrigger : onLeave';
}
function ONENTERBACK(){
	document.querySelector(".ScrollTrigger_fix").innerHTML = 'ScrollTrigger : onEnterBack';
}
function ONLEAVEBACK(){
	document.querySelector(".ScrollTrigger_fix").innerHTML = 'ScrollTrigger : onLeaveBack';
}




// 시작/종료 지점 선택
// startEnd_box
gsap.to(".startEnd_box", {
	scrollTrigger: {
		trigger: ".startEnd_box",
		toggleActions: "resume pause reset pause",
		markers: true,
		start: "top center",
	},
	x: 400, duration: 4,
});





// Scrub
gsap.to(".scrub_box1", {
	scrollTrigger: {
		trigger: ".scrub_box1",
		markers: true,
		start: "top center",
		scrub: true,
	},
	x: 400, duration: 4,
});
gsap.to(".scrub_box2", {
	scrollTrigger: {
		trigger: ".scrub_box2",
		markers: true,
		start: "top center",
		scrub: 3,
	},
	x: 400, duration: 4,
});



// pinning
gsap.to(".pinning_box1", {
	scrollTrigger: {
		trigger: ".pinning_box1",
		markers: true,
		start: "top center",
		scrub: true,
		pin: true,
	},
	x: 400, duration: 4,
});
gsap.to(".pinning_box2", {
	scrollTrigger: {
		trigger: ".pinning_box2",
		markers: true,
		start: "top center",
		scrub: 3,
		pin: true,
	},
	x: 200, duration: 4,
});




// pinning one page scroll
// gsap.defaults({ease: "power1", duration: 3});

const tl = gsap.timeline();
tl.from(".gsap_pinning_onpage3", {xPercent: -100})
  .from(".gsap_pinning_onpage4", {xPercent: 100})
  .from(".gsap_pinning_onpage5", {yPercent: 100});

ScrollTrigger.create({
	trigger: "#gsap_pinning_onpage_container",
	animation: tl,
	start: "top top", 
	end: "+=4000",
	pin: true,
	scrub: true,
	anticipatePin: 1
});
